<?php
// db_config.php

// 1. Configurare Bază de Date (Aliniată cu docker-compose.yml)
define('DB_SERVER', 'db'); // Numele serviciului din docker-compose.yml
define('DB_USERNAME', 'app_user'); 
define('DB_PASSWORD', 'secret_password');
define('DB_NAME', 'student_catalog');

// 2. Crează conexiunea
$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// 3. Verifică conexiunea
if ($conn->connect_error) {
    // În mediul Docker, erorile de conexiune pot indica o problemă cu DB_SERVER ('db') sau credențialele
    http_response_code(500); 
    die("Eroare la conectarea la baza de date: " . $conn->connect_error);
}

// 4. Setează charset-ul 
$conn->set_charset("utf8");

return $conn;
?>